package net.fabricmc.AVCD.modcheck.network;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;
import net.fabricmc.AVCD.modcheck.server.ModListServer;

public class ModListPacket {
    public static final class_2960 MOD_LIST_PACKET = new class_2960("modcheck", "mod_list");
    
    public static void registerServerReceiver() {
        ServerPlayNetworking.registerGlobalReceiver(MOD_LIST_PACKET, ModListPacket::receive);
    }
    
    private static void receive(MinecraftServer server, class_3222 player, 
                               class_3244 handler, class_2540 buf, 
                               PacketSender responseSender) {
        int modCount = buf.readInt();
        String[] clientMods = new String[modCount];
        
        for (int i = 0; i < modCount; i++) {
            clientMods[i] = buf.method_19772();
        }
        
        server.execute(() -> {
            ModListServer.processClientMods(player, clientMods);
        });
    }
    
    public static class_2540 createPacket(String[] mods) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeInt(mods.length);
        for (String mod : mods) {
            buf.method_10814(mod);
        }
        return buf;
    }
}